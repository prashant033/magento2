<?php

namespace Mastering\SampleModule\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
       // $setup->getConnection()->query("INSERT INTO inviqa_example SET name = 'Test 1'");
    	$setup->startSetup();
    	$setup->getConnection()->insert(
    		$setup->getTable('mastering_sample_item'),
    		[
    			'name' => 'item 1'
    		]
    	);
    	$setup->getConnection()->insert(
    		$setup->getTable('mastering_sample_item'),
    		[
    			'name' => 'item 2'
    		]
    	);
    	$setup->endSetup();

    }
}