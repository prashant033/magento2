<?php
/**
 * Created by PhpStorm.
 * User: pragauta1
 * Date: 8/7/2018
 * Time: 11:27 PM
 */

namespace Mastering\SampleModule\Cron;
use Mastering\SampleModule\Model\ItemFactory;

class AddItem
{
    private $itemFactory;
    public function __construct(ItemFactory $itemFactory)
    {
        $this->itemFactory=$itemFactory;
    }

    public function execute()
    {
        $this->itemFactory->create()
            ->setName('Custom cron jobs item add')
            ->setDescription('Created custom cron jobs items' .time())
            ->save();
    }
}
