<?php
namespace Pfay\Contacts\Block\Product;

class View extends \Magento\Catalog\Block\Product\View
{
    /**
     * Retrieve current product model
     *
     * @return \Magento\Catalog\Model\Product
     */
   /* public function getProduct()
    {
    	echo "block overide in Magento2";
       //die('test rewrite block product view');
    }*/
}